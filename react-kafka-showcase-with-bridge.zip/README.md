# React + Kafka Showcase

See canvas for full details.